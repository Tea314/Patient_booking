export let departments = [{
  id: 1,
  name: "Co xuong khop",
  images: "images\\101627-co-xuong-khop.png"
}, {
  id: 2,
  name: "Than kinh",
  images: "images\\101739-than-kinh.png"
}, {
  id: 3,
  name: "Tieu hoa",
  images: "images\\101713-tieu-hoa.png"
}, {
  id: 4,
  name: "Tim mach",
  images: "images\\101713-tim-mach.png"
}]