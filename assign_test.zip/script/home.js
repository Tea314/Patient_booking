document.querySelector('.right').addEventListener('click', () => {
  window.location.href = 'department-booking.html';
})